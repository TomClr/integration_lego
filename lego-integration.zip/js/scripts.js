$(document).ready(function() {

    $('.menu > li a').on('click', function() {
        $('.menu > li a.active').removeClass('active');
        $(this).addClass('active');
    });

    /* if ($(window).width() < 937 + 'px') {
        $('.has-children').on("click", function() {
            $('.has-children > .sous-menu').css("display", "block");
        })
    } */

});
